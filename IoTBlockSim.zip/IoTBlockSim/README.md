# IoTSim-Osmosis
`https://github.com/kalwasel/IoTSim-Osmosis` <br>
IoTSim-Osmosis is a simulation framework that supports the testing and validation of osmotic computing applications. In particular, it enables a unified modelling and simulation of complex IoT applications over heterogeneous edge-cloud SDN-aware environments. A wide range of osmosis applications can be simulated and evaluated in IoTSim-Osmosis. For more information, read IoTSim-Osmosis_User_Manual.pdf.

# IoTBlockSim
IoTBlockSim is a framework that extends IoTSim-Osmosis by adding a blockchain simulation layer. <br>
Main module: `org.cloudbus.blockchain` <br>
Instructions for environment setup are provided in: `IoTSim-Osmosis_User_Manual.pdf` <br>
To run an example application, run: `org.cloudbus.cloudsim.osmesis.examples.OsmesisExample_2_BC.java` <br>
An example application contains an IoT simulation provided by IoTSim-Osmosis with added blockchain simulation. The application produces both IoT and blockchain simulation outputs.
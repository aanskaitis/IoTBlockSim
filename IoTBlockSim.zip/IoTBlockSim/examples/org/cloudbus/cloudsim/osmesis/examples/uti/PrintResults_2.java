/*
 * Title:        IoTSim-Osmosis 1.0
 * Description:  IoTSim-Osmosis enables the testing and validation of osmotic computing applications 
 * 			     over heterogeneous edge-cloud SDN-aware environments.
 * 
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2020, Newcastle University (UK) and Saudi Electronic University (Saudi Arabia) 
 * 
 */

package org.cloudbus.cloudsim.osmesis.examples.uti;


import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.edge.core.edge.EdgeDataCenter;
import org.cloudbus.cloudsim.edge.core.edge.EdgeLet;
import org.cloudbus.osmosis.core.*;
import org.cloudbus.blockchain.*;
import java.util.Random;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;


/**
 * 
 * @author Khaled Alwasel
 * @contact kalwasel@gmail.com
 * @since IoTSim-Osmosis 1.0
 * 
**/

public class PrintResults_2 {
		
	public void printOsmesisNetwork() {		
		
		List<WorkflowInfo> tags = new ArrayList<>();
		
		for(OsmesisAppDescription app : OsmesisAppsParser.appList){
			int txId = 0;
			BCInit.initialize();
			
			for(WorkflowInfo workflowTag : OsmesisBroker.workflowTag){
				workflowTag.getAppId();
				
				if(app.getAppID() == workflowTag.getAppId()){
					tags.add(workflowTag);
					
					// Blockchain
					for (Flow flow : workflowTag.getFlowLists()) {
						int srcId = flow.getOrigin();
						int destId = flow.getDestination();
						
						// Check if both source and destination is either IoT or edge device
						if (BCNetwork.idToNodeMap.keySet().contains(srcId) && BCNetwork.idToNodeMap.keySet().contains(destId)) {
							Object txData = "";
							
							Node srcNode = BCNetwork.idToNodeMap.get(srcId);
							Transaction tx = srcNode.createTx(txId, destId, txData);
							srcNode.propagateTx(tx, BCNetwork.heavyNodes);
							txId += 1;
						} else {
							continue;
						}
					}
					
					HeavyNode miner = BCNetwork.chooseMiner();
					
					Block newBlock = miner.createBlock();
					miner.propagateBlock(newBlock, BCNetwork.heavyNodes);
					miner.incrementMinedBlocks();
				}
			}
			BCTime.setEndTime(BCTime.now());
			
			printBCSimResults(app.getAppID());
			printOsmesisApp(tags);		
			tags.clear();
		}
		
		Log.printLine();				
		Log.printLine("=========================== Osmesis Overall Apps Results ========================");
		Log.printLine(String.format("%1s %19s %32s %16s %14s %19s %25s"
				, "App_Name"
				, "IoTDeviceDrained"
				, "IoTDeviceBatteryConsumption"
				, "StartTime" 
				, "EndTime" 
				, "SimluationTime"
				, "appTotalRunningTmie"));

		for(OsmesisAppDescription app : OsmesisAppsParser.appList){
			for(WorkflowInfo workflowTag : OsmesisBroker.workflowTag){
				workflowTag.getAppId();
				if(app.getAppID() == workflowTag.getAppId()){
					tags.add(workflowTag);
				}
			}			
			printAppStat(app, tags);
			tags.clear();
		}
//		printAppWorkflowConfigration();
	}
	
	private void printBCSimResults(int app_id) {
		
		List<Block> ledger = BCNetwork.heavyNodes.get(0).getLedger();
		
		// Calculate average time between block creation and block receival
		long blockCreateToReceiveTime = 0;
		int numberOfBlockReceivals = 0;
		
		for (Block block : ledger) {
			
			for (long timeReceived : block.getTimeReceived()) {
				blockCreateToReceiveTime += timeReceived - block.getTimeCreated();
			}
			
			numberOfBlockReceivals += block.getTimeReceived().size();
		}

		long avgBlockCreateToReceiveTime = (long) blockCreateToReceiveTime / numberOfBlockReceivals;
		
		// Calculate average time between transaction creation and transaction receival
		long txCreateToReceiveTime = 0;
		int numberOfTxReceivals = 0;
		
		for (Block block : ledger) {
			
			for (Transaction tx : block.getTransactions()) {
				for (long timeReceived : tx.getTimeReceived()) {
					txCreateToReceiveTime += timeReceived - tx.getTimeCreated();
				}
				numberOfTxReceivals += tx.getTimeReceived().size();
			}
		}

		long avgTxCreateToReceiveTime = (long) txCreateToReceiveTime / numberOfTxReceivals;
		
		
		Log.printLine();
		Log.printLine("=========================== Blockchain Simulation Results ========================");
		Log.printLine("App id: " + app_id);
		long duration = BCTime.getEndTime() - BCTime.getStartTime();
		Log.printLine("Total simulation duration: " + duration + " milliseconds");
		Log.printLine("Block propagation delay: " + BCInputs.blockPropagationDelay + " milliseconds");
		Log.printLine("Average time between block creation and receival: " + avgBlockCreateToReceiveTime + " milliseconds");
		Log.printLine("Transaction propagation delay: " + BCInputs.txPropagationDelay + " milliseconds");
		Log.printLine("Average time between transaction creation and receival: " + avgTxCreateToReceiveTime + " milliseconds");
		Log.printLine();
		Log.printLine("============= Hash Power and Number of Mined Blocks Comparison ===============");
		for (HeavyNode node : BCNetwork.heavyNodes) {
			Log.printLine("Node id: " + node.getId());
			Log.printLine("Hash power (% of network): " + node.getHashPower() * 100);
			double minedBlocksPercentage = (double) node.getMinedBlocks() / ledger.size() * 100;
			Log.printLine("Mined blocks (% of network): " + minedBlocksPercentage);
			Log.printLine("=======================");
		}
	}
	
	private void printAppWorkflowConfigration() {
		Log.printLine();				
		Log.printLine("=========================== Osmesis Workflow Configrations ========================");
		Log.printLine(String.format("%1s %17s %26s  %13s  %30s %13s %21s %23s %12s %21s"				
				,"App_Name"   				
				, "DataRate_Sec"
				, "StopDataGeneration_Sec"
				, "IoTDevice"
				, "IoTDeviceOutputData_Mb"
				, "MELName"
				, "OsmesisEdgelet_MI"  				 				
				, "MELOutputData_Mb"
				, "VmName"  				   
				, "OsmesisCloudlet_MI" 
				));
		for(OsmesisAppDescription app : OsmesisAppsParser.appList){
			Log.printLine(String.format("%1s %15s %21s  %25s  %18s %22s %15s %24s %18s %14s"				
					, app.getAppName()   				
					, app.getDataRate()
					, app.getStopDataGenerationTime()
					, app.getIoTDeviceName()
					, app.getIoTDeviceOutputSize()
					, app.getMELName()
					, app.getOsmesisEdgeletSize()  				 				
					, app.getMELOutputSize()
					, app.getVmName()  				   
					, app.getOsmesisCloudletSize() 
					));							
		}		
	}

	private void printAppStat(OsmesisAppDescription app, List<WorkflowInfo> tags) {		 	
		String appName = app.getAppName();
		String isIoTDeviceDrained = app.getIoTDeviceBatteryStatus();
		double iotDeviceTotalConsumption = app.getIoTDeviceBatteryConsumption();
//		long TotalIoTGeneratedData = 0;
//		long TotalEdgeLetSizes = 0;
//		long TotalMELGeneratedData = 0;
//		long TotalCloudLetSizes = 0;
		double StartTime = 0;
		double EndTime = 0;
		double SimluationTime = 0;
		double appTotalRunningTmie = 0;
		

		
		StartTime = app.getAppStartTime();
		int transactionListSize = tags.size()-1;
		int lastOsmosisLet = tags.get(transactionListSize).getOsmosisLetSize();
		EndTime = tags.get(transactionListSize).getOsmosislet(lastOsmosisLet-1).getFinishTime();
		SimluationTime = EndTime - StartTime;
		
		WorkflowInfo firstWorkflow = tags.get(0);
		WorkflowInfo secondWorkflow = tags.get(1);
		
		if(firstWorkflow.getFinishTime() > secondWorkflow.getSartTime()){
			appTotalRunningTmie = EndTime - StartTime;			
		} else {
			for(WorkflowInfo workflowTag : tags){
				appTotalRunningTmie += workflowTag.getFinishTime() - workflowTag.getSartTime(); 
			}
		}

//		for(WorkflowInfo workflowTag : tags){
//			for(){
//			TotalIoTGeneratedData += workflowTag.getOsmosisFlow(0).getSize();
//			TotalEdgeLetSizes += workflowTag.getEdgeLet_1().getCloudletLength() +
//					workflowTag.getEdgeLet_2().getCloudletLength();
//			TotalMELGeneratedData += workflowTag.getOsmosisFlow(1).getSize() +
//					workflowTag.getOsmosisFlow(2).getSize();
//			TotalCloudLetSizes += workflowTag.getCloudLet().getCloudletLength();
//			}
//		}

		Log.printLine(String.format("%1s %15s %28s %24s %17s %15s %22s"
				, appName
				, isIoTDeviceDrained
				,  new DecimalFormat("0.00").format(iotDeviceTotalConsumption)
				,  new DecimalFormat("0.000").format(StartTime) 
				,  new DecimalFormat("0.000").format(EndTime) 
				,  new DecimalFormat("0.000").format(SimluationTime)
				,  new DecimalFormat("0.000").format(appTotalRunningTmie)				
				));
	}
	
	public double detemineMaxValue(double oldValue, double newValue){
		if(oldValue < newValue){
			oldValue  = newValue;	
		}
		return oldValue;
	}

	public void printNetworkStatistics(Flow flow){				
			Log.printLine(String.format("%1s %21s %12s %19s %15s %12s %11s %22s %16s %22s "
					, flow.getFlowId()
					, "" 					
					, flow.getAppName() 
					, ""
					, flow.getAppNameSrc() 
					, flow.getAppNameDest()
					, flow.getSize()  					
					, new DecimalFormat("0.0000").format(flow.getStartTime()) 
					, new DecimalFormat("0.0000").format(flow.getFinishTime() -  flow.getStartTime())   
					, new DecimalFormat("0.0000").format(flow.getFinishTime())));		
	}
	
	
	public void printOsmesisApp(List<WorkflowInfo> tags) {
		Log.printLine();				
		Log.printLine("=========================== Osmesis App Results ========================");
		Log.printLine(String.format("%1s %11s %18s %17s %17s %19s %20s %35s %37s %21s %29s %29s %33s %15s %30s %28s %17s %29s %30s %35s %15s %30s %28s %17s %29s %30s %35s %23s %25s %28s %18s %22s %22s %32s %25s"
				,"App_ID"
				,"AppName"
				,"Transaction"
				,"StartTime"
				,"FinishTime"
				,"IoTDeviceName"
				,"MELName_1"
				,"DataSizeIoTDeviceToMEL_Mb"  
				,"TransmissionTimeIoTDeviceToMEL"
				,"EdgeLetMISize"
				,"EdgeLet_MEL_StartTime"
				,"EdgeLet_MEL_FinishTime"
				,"EdgeLetProccessingTimeByMEL"
				// renewable energy
				,"MELName_2"
				,"DataSizeMELToMEL_Mb"
				,"TransmissionTimeMELToMEL"
				,"EdgeLetMISize"
				,"EdgeLet_MEL_StartTime"
				,"EdgeLet_MEL_FinishTime"
				,"EdgeLetProccessingTimeByMEL"
				// renewable energy
				,"MELName_3"
				,"DataSizeMELToMEL_Mb"
				,"TransmissionTimeMELToMEL"
				,"EdgeLetMISize"
				,"EdgeLet_MEL_StartTime"
				,"EdgeLet_MEL_FinishTime"
				,"EdgeLetProccessingTimeByMEL"
				// renewable energy
				,"DestinationVmName"
				,"DataSizeMELToVM_Mb"
				,"TransmissionTimeMELToVM"  
				,"CloudLetMISize"
				,"CloudLet_StartTime"
				,"CloudLet_FinishTime"
				,"CloudLetProccessingTimeByVM"  						
				, "TransactionTotalTime"
				, "   "));

		double transactionTransmissionTime = 0;
		double transactionOsmosisLetTime = 0;

		double transactionTotalTime;
		for(WorkflowInfo workflowTag : tags){
			transactionTransmissionTime = 0;
			transactionOsmosisLetTime = 0;
			transactionTotalTime = 0;

			for(int i = 0; i < workflowTag.getFlowLists().size(); i++){
				Flow flow = workflowTag.getOsmosisFlow(i);
				transactionTransmissionTime += flow.getTransmissionTime();
			}

			for(int x =0; x < workflowTag.getOsmosisLetSize(); x++){
				EdgeLet let = workflowTag.getOsmosislet(x);
				transactionOsmosisLetTime += let.getActualCPUTime();
			}
			transactionTotalTime = transactionTransmissionTime +  transactionOsmosisLetTime;
			Log.printLine(String.format("%1s %15s %15s %18s %18s %21s %23s %21s %34s %32s %24s %28s %31s %30s %18s %26s %23s %24s %28s %31s %37s  %18s %26s %23s %24s %28s %31s %32s %18s %26s %23s %20s %23s %24s %28s"
					, workflowTag.getAppId()
					, workflowTag.getAppName()
					, workflowTag.getWorkflowId()	
					, new DecimalFormat("0.00").format(workflowTag.getSartTime())
					, new DecimalFormat("0.00").format(workflowTag.getFinishTime())
					, workflowTag.getOsmosisFlow(0).getAppNameSrc()
					, workflowTag.getOsmosisFlow(0).getAppNameDest() + " (" +workflowTag.getDCName(0) + ")"
					, workflowTag.getOsmosisFlow(0).getSize()
					, new DecimalFormat("0.00").format(workflowTag.getOsmosisFlow(0).getTransmissionTime())
					, workflowTag.getOsmosislet(0).getCloudletLength()
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(0).getExecStartTime())
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(0).getFinishTime())
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(0).getActualCPUTime())

					// renewable energy
					, workflowTag.getOsmosisFlow(1).getAppNameDest() + " (" +workflowTag.getDCName(1) + ")"
					, workflowTag.getOsmosisFlow(1).getSize()
					, new DecimalFormat("0.00").format(workflowTag.getOsmosisFlow(1).getTransmissionTime())
					, workflowTag.getOsmosislet(1).getCloudletLength()
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(1).getExecStartTime())
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(1).getFinishTime())
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(1).getActualCPUTime())

					// renewable energy
					, workflowTag.getOsmosisFlow(2).getAppNameDest() + " (" +workflowTag.getDCName(2) + ")"
					, workflowTag.getOsmosisFlow(2).getSize()
					, new DecimalFormat("0.00").format(workflowTag.getOsmosisFlow(2).getTransmissionTime())
					, workflowTag.getOsmosislet(2).getCloudletLength()
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(2).getExecStartTime())
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(2).getFinishTime())
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(2).getActualCPUTime())


					, workflowTag.getOsmosisFlow(3).getAppNameDest() + " (" +workflowTag.getDCName(3) + ")"
					, workflowTag.getOsmosisFlow(3).getSize()
					, new DecimalFormat("0.00").format(workflowTag.getOsmosisFlow(3).getTransmissionTime())
					, workflowTag.getOsmosislet(3).getCloudletLength()
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(3).getExecStartTime())
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(3).getFinishTime())
					, new DecimalFormat("0.00").format(workflowTag.getOsmosislet(3).getActualCPUTime())
					, new DecimalFormat("0.00").format(transactionTotalTime)));
		}
	}	
}

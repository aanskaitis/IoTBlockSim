package org.cloudbus.blockchain;

import java.util.List;
import java.util.ArrayList;

public class Transaction {
	private int id;
    private int senderId;
    private int receiverId;
    private double size;
    private Object data;
    private long timeCreated;
    private List<Long> timeReceived = new ArrayList<>();
    
	public Transaction(int id, int senderId, int receiverId, double size, Object data, long timeCreated){
        this.id = id;
		this.senderId = senderId;
        this.receiverId = receiverId;
        this.size = size;
        this.data = data;
        this.timeCreated = timeCreated;
    }
	
	public int getId() {
        return id;
    }

    public int getSenderId() {
        return senderId;
    }

    public void setSenderId(int senderId) {
        this.senderId = senderId;
    }

    public int getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(int receiverId) {
        this.receiverId = receiverId;
    }

    public double getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public long getTimeCreated() {
        return timeCreated;
    }

    public List<Long> getTimeReceived(){
    	return timeReceived;
    }
    
    public void addTimeReceived(long time) {
    	timeReceived.add(time);
    }
}

package org.cloudbus.blockchain;

public class BCInputs {
	public static double txSize = 0.0005;
    public static double blockSize = 1.0;
    
    public static long blockPropagationDelay = (long) 5;
    public static long txPropagationDelay = (long) 2;
}

package org.cloudbus.blockchain;

public class BCInit {
	
	public static void initialize() {
		BCTime.initClock();
		BCNetwork.normalizeHashPower();
		initGenesisBlock();
	}
	
	private static void initGenesisBlock() {
		Block genesisBlock = Block.createGenesisBlock();
		
		Block.propagateBlock(genesisBlock, BCNetwork.heavyNodes);
	}
}

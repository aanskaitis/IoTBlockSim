package org.cloudbus.blockchain;

import java.util.List;

import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.core.CloudSim;

import java.util.ArrayList;

public class HeavyNode extends Node {

	private double hashPower;
	private List<Transaction> txPool = new ArrayList<>();
	private List<Block> ledger = new ArrayList<>();
	private int minedBlocks = 0;
	
	/*
	 * HeavyNode constructor without hashing power
	 */
	public HeavyNode(int id) {
		super(id);
	}
	
	/*
	 * HeavyNode constructor with hashing power
	 */
	public HeavyNode(int id, double hashPower) {
		super(id);
		this.hashPower = hashPower;
	}
	
	public int getMinedBlocks() {
		return minedBlocks;
	}
	
	public void incrementMinedBlocks() {
		minedBlocks += 1;
	}
	
	public double getHashPower() {
		return hashPower;
	}
	
	public void setHashPower(double hashPower) {
		this.hashPower = hashPower;
	}
	
	public List<Transaction> getTxPool() {
        return txPool;
    }

    public void setTxPool(List<Transaction> txPool) {
        this.txPool = txPool;
    }

    public List<Block> getLedger() {
        return ledger;
    }

    public void setLedger(List<Block> ledger) {
        this.ledger = ledger;
    }
	
	public boolean verifyTx(Transaction tx) {
		return true;
	}
	
	public void receiveTx(Transaction tx) {
		tx.addTimeReceived(BCTime.now());
		
		if (verifyTx(tx)) {
			txPool.add(tx);
		}
	}
	
    public Block getLastBlock(){
        return ledger.get(ledger.size() - 1);
    }
    
	public Block createBlock() {
        Block prevBlock = getLastBlock();

        List<Transaction> txToInclude = new ArrayList<>();
        txToInclude.addAll(txPool);
        
        return new Block(prevBlock.getId() + 1, prevBlock.getId(), id, BCInputs.blockSize,
                prevBlock.getHeight() + 1, txToInclude, BCTime.now());
    }
	
	public void propagateBlock(Block block, List<HeavyNode> nodes) {
		try {
			Thread.sleep(BCInputs.blockPropagationDelay);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		for (HeavyNode node : nodes) {
			node.receiveBlock(block);
		}
	}
	
	public boolean verifyBlock(Block block) {
		return true;
	}
	
	public void receiveBlock(Block block) {
		block.addTimeReceived(BCTime.now());
		
		if (verifyBlock(block)) {
			ledger.add(block);
			updateTxPool(block);
		}
	}
	
	// update tx pool upon block arrival
	public void updateTxPool(Block block) {
		List<Transaction> transactions = block.getTransactions();

		txPool.removeAll(transactions);
	}
}

package org.cloudbus.blockchain;
import java.util.List;
import java.util.ArrayList;
import org.cloudbus.cloudsim.Log;


public class Block {

	private int id = 0;
    private int prevId;
    private int minerId;
    private double size;
    private int height;
    private List<Transaction> transactions;
    private long timeCreated;
    private List<Long> timeReceived = new ArrayList<>();

    public Block(int id, int prevId, int minerId, double size, int height,
                 List<Transaction> transactions, long timeCreated) {
        this.id = id;
        this.prevId = prevId;
        this.minerId = minerId;
        this.size = size;
        this.height = height;
        this.transactions = transactions;
        this.timeCreated = timeCreated;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrevId() {
        return prevId;
    }

    public void setPrevId(int prevId) {
        this.prevId = prevId;
    }

    public int getMinerId() {
        return minerId;
    }

    public void setMinerId(int minerId) {
        this.minerId = minerId;
    }

    public double getSize() {
        return size;
    }

    public void setSize(double size) {
        this.size = size;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    public long getTimeCreated() {
        return timeCreated;
    }

    public List<Long> getTimeReceived(){
    	return timeReceived;
    }
    
    public void addTimeReceived(long time) {
    	timeReceived.add(time);
    }
    
    public static Block createGenesisBlock() {
    	return new Block(0, -1, -1, BCInputs.blockSize, 0, new ArrayList<>(), BCTime.now());
    }
    
    public static void propagateBlock(Block block, List<HeavyNode> nodes) {
    	for (HeavyNode node : nodes) {
    		node.receiveBlock(block);
    	}
    }
}


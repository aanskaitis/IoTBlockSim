package org.cloudbus.blockchain;

import java.util.List;


public abstract class Node {

	protected int id;
	
	public Node(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public Transaction createTx(int txId, int receiverId, Object data) {
		int senderId = this.id;
		
		return new Transaction(txId, senderId, receiverId, BCInputs.txSize, data, BCTime.now());
	}
	
	public void propagateTx(Transaction tx, List<HeavyNode> nodes) {
		try {
			Thread.sleep(BCInputs.txPropagationDelay);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		for (HeavyNode node : nodes) {
			node.receiveTx(tx);
		}
	}
}

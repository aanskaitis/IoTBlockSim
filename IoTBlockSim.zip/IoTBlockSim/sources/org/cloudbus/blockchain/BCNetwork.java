package org.cloudbus.blockchain;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.HashMap;

public class BCNetwork {

	public static List<LightNode> lightNodes = new ArrayList<>();
	public static List<HeavyNode> heavyNodes = new ArrayList<>();
	public static HashMap<Integer, Node> idToNodeMap = new HashMap<Integer, Node>();
	
	public static void initLightNode(int id) {
		LightNode node = new LightNode(id);
		
		// sign the service level agreement
		SLA.sign(node, "");
		
		lightNodes.add(node);
		idToNodeMap.put(id, node);
	}
	
	public static void initHeavyNode(int id) {
		HeavyNode node = new HeavyNode(id);
		
		// sign the service level agreement
		SLA.sign(node, "Hold transaction pool and full blockchain ledger. Perform block mining.");
		
		heavyNodes.add(node);
		idToNodeMap.put(id, node);
	}
	
	public static void initHeavyNode(int id, double hashPower) {
		HeavyNode node = new HeavyNode(id, hashPower);
		
		// sign the service level agreement
		SLA.sign(node, "Hold transaction pool and full blockchain ledger. Perform block mining.");
		
		heavyNodes.add(node);
		idToNodeMap.put(id, node);
	}
	
	public static HeavyNode chooseMiner() {
		Random rand = new Random();
		HeavyNode miner = heavyNodes.get(0);
		double priority = 0;
		
		for (HeavyNode node : heavyNodes) {
			double random = rand.nextDouble();
			int hashPowerSignificance = 1;
			double nodePriority = (hashPowerSignificance + random) * node.getHashPower();
			
			if (nodePriority > priority) {
				priority = nodePriority;
				miner = node;
			}
		}
		
		return miner;
	}
	
	public static void normalizeHashPower() {
		double totalHashPower = 0;
		
		for (HeavyNode node : heavyNodes) {
			totalHashPower += node.getHashPower();
		}
		
		for (HeavyNode node : heavyNodes) {
			double currentHashPower = node.getHashPower();
			node.setHashPower(currentHashPower / totalHashPower);
		}
	}
}

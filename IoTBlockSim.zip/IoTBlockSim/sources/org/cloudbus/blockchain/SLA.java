package org.cloudbus.blockchain;
import java.util.HashMap;

public class SLA {

	private static HashMap<Node, Object> agreement = new HashMap<Node, Object>();
	
	public static void sign(Node node, Object responsibilities) {
		agreement.put(node, responsibilities);
	}
	
	public static HashMap<Node, Object> getSLA(){
		return agreement;
	}
}

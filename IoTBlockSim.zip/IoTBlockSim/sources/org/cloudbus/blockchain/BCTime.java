package org.cloudbus.blockchain;
import java.sql.Timestamp;

import org.cloudbus.cloudsim.Log;

public class BCTime {
	private static long startTime;
	private static long endTime;
	
	public static void initClock() {
		startTime = now();
	}
	
	public static long getStartTime() {
		return startTime;
	}
	
	public static long getEndTime() {
		return endTime;
	}
	
	public static void setEndTime(long time) {
		endTime = time;
	}
	
	public static long now() {
		Timestamp clock = new Timestamp(System.currentTimeMillis());
		return clock.getTime();
	}
}

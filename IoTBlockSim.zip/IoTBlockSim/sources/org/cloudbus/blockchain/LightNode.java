package org.cloudbus.blockchain;

public class LightNode extends Node {
	
	public LightNode(int id) {
		super(id);
	}
}

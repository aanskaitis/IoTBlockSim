package org.cloudbus.cloudsim.power.lists;

public class AAAAA {

}
